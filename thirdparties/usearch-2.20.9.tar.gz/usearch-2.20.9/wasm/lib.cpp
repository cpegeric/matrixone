#define USEARCH_EXPORT EMSCRIPTEN_KEEPALIVE

#include <emscripten/emscripten.h>

#include <../c/lib.cpp>
