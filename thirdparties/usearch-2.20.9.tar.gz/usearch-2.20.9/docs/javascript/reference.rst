API Reference
===============

==================
usearch.Index
==================

.. ts:autoclass:: Index
   :members:

.. ts:autoclass:: Matches
   :members:
