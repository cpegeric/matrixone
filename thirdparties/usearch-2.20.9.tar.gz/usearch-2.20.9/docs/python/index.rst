==============
Python SDK
==============


.. mdinclude:: ../../python/README.md

.. toctree::
   :hidden:

   reference